import os
import numpy
import operator
import time, datetime


import random

from keras.utils import to_categorical

class DataLoader:
	def __init__(self, activitiesFile, sensorsFile, activitiesDataFile):
		self.activitiesFile = activitiesFile
		self.sensorsFile = sensorsFile
		self.activitiesDataFile = activitiesDataFile

		self.activities = []
		self.reversedActivites = []
		self.sensors = []
		self.reversedSensors = []
		self.dataSeries = []
				
		self.activitiesSize = 0
		self.sensorsSize = 0
		
	def loadActivities(self):
		activitiesFile = open(self.activitiesFile, "r")
		activities = {}
		
		for line in activitiesFile:
			activity = line.split(',')
			activities[activity[2]] = int(activity[3])
		
		reversedActivities = dict(zip(activities.values(), activities.keys()))
		
		activitiesSize = len(activities)
		
		return activities, reversedActivities, activitiesSize
	
	def loadSensors(self):
		sensorsFile = open(self.sensorsFile, "r")
		sensors = {}
		
		for line in sensorsFile:
			sensor = line.split(',')
			sensors[sensor[2].strip()+'_'+sensor[1].strip()+'_'+str(sensor[0])] = int(sensor[0])
		
		reversedSensors = dict(zip(sensors.values(), sensors.keys()))
		
		sensorsSize = len(sensors)
		
		return sensors, reversedSensors, sensorsSize
	
	def loadDataSeries(self):
		dataFile = open(self.activitiesDataFile, "r")
		dataLines = dataFile.read().split('\n')
		data = []
		
		for i in range(0, len(dataLines)-1, 5):
			dataActivity = dataLines[i].split(',')
			dataSensors = dataLines[i+1].split(',')
			dataStartTimes = dataLines[i+3].split(',')
			dataEndTimes = dataLines[i+4].split(',')

			aux = {}
			
			for j in range(len(dataSensors)):
				start = time.mktime(datetime.datetime.strptime(str(dataActivity[1])+" "+str(dataStartTimes[j]), "%m/%d/%Y %H:%M:%S").timetuple())
				end = time.mktime(datetime.datetime.strptime(str(dataActivity[1])+" "+str(dataEndTimes[j]), "%m/%d/%Y %H:%M:%S").timetuple())
				
				if len(data) == 0:
					data.append({'sensorId':dataSensors[j], 'command': 'on', 'timestamp':start})
					data.append({'sensorId':dataSensors[j], 'command': 'off', 'timestamp':end})
				else:
					inserted = False
					
					for k in range(0, len(data)):
						if start < data[k]['timestamp']:
							aux = {'sensorId':dataSensors[j], 'command': 'on', 'timestamp':start}
							data.insert(k, aux)
							inserted = True
							break
					
					if not inserted:
						data.append({'sensorId':dataSensors[j], 'command': 'on', 'timestamp':start})
						data.append({'sensorId':dataSensors[j], 'command': 'off', 'timestamp':end})
					else:
						for k in range(0, len(data)):
							if end < data[k]['timestamp']:
								aux = {'sensorId':dataSensors[j], 'command': 'off', 'timestamp':end}
								data.insert(k, aux)
								break
		
		return data
	
"""	def splitData(self, xData, yData, percentage):
		nValues = int(xData.shape[0]*percentage)
		
		xFirst = []
		yFirst = []
		xSecond = []
		ySecond = []
		
		for i in range(nValues):
			size = xData.shape[0]
			index = random.randint(0,size-1)
			xFirst.append(xData[index])
			yFirst.append(yData[index])
			xData = numpy.delete(xData, index, 0)
			yData = numpy.delete(yData, index, 0)
		
		xSecond = xData
		ySecond = yData
		
		xFirst = numpy.asarray(xFirst)
		xFirst = xFirst.astype('float32')
		yFirst = numpy.asarray(yFirst)
		yFirst = yFirst.astype('float32')
		
		xSecond = numpy.asarray(xSecond)
		xSecond = xSecond.astype('float32')
		ySecond = numpy.asarray(ySecond)
		ySecond = ySecond.astype('float32')
		
		return xFirst, yFirst, xSecond, ySecond	
	
	def getFormattedData(self):
		activities, reversedActivities, activitiesSize, activitiesIndexTranslation = self.loadActivities()
		sensors, reversedSensors, sensorsSize, sensorsIndexTranslation = self.loadSensors()
		activitiesData = self.loadActivitiesData()
		maxActivityLength = 0
		
		self.activities = activities
		self.reversedActivities = reversedActivities
		self.activitiesIndexTranslation = activitiesIndexTranslation
		self.sensors = sensors
		self.reversedSensors = reversedSensors
		self.sensorsIndexTranslation = sensorsIndexTranslation
		
		for activity in activitiesData:
			length = int(activity['endTimestamp']) - int(activity['startTimestamp'])

			if length > maxActivityLength:
				maxActivityLength = length
		
		maxActivityLength += 1
		
		maxActivityLength = min(maxActivityLength, self.maxNumSamples)
		
		xData = []
		yData = []
		
		for activity in activitiesData:
			aux = numpy.zeros((sensorsSize, maxActivityLength))
			startTimestamp = int(activity['startTimestamp'])
			endTimestamp = int(activity['endTimestamp'])
			
			for sensor in activity['sensors']:
				idIndex = int(self.getIndexFromId(sensorsIndexTranslation, sensor['id']))

				sensorStartTimestamp = int(sensor['startTimestamp'])
				sensorEndTimestamp = int(sensor['endTimestamp'])

				start = max(0, sensorStartTimestamp-startTimestamp)
				end = min(maxActivityLength, (sensorEndTimestamp-startTimestamp)+1)
				for timestampIndex in range(start, end):
					aux[int(idIndex), int(timestampIndex)] = 1

			activityIndex = int(self.getIndexFromId(activitiesIndexTranslation, activities[activity['activity']]))
					
			yData.append(activityIndex)
			xData.append(aux)
		
		xData = numpy.asarray(xData).reshape(-1, sensorsSize, maxActivityLength)
		xData = xData.astype('float32')
		
		yData = numpy.asarray(yData)
		yData = to_categorical(yData, activitiesSize)
		yData = yData.astype('float32')
		
		self.activitiesSize = activitiesSize
		self.sensorsSize = sensorsSize
		self.numSamples = maxActivityLength
		
		return xData, yData
	
	def getActivitiesSize(self):
		return self.activitiesSize
		
	def getSensorsSize(self):
		return self.sensorsSize
	
	def getNumSamples(self):
		return self.numSamples
	
	def getIndexFromId(self, translationObject, Id):
		for i in range(len(translationObject)):
			if int(translationObject[i]) == int(Id):
				return i
				
	def getIdFromIndex(self, translationObject, index):
		return translationObject[int(index)]
	
	def getActivitiesLabels(self):
		labels = []
		for i in range(self.activitiesSize):
			activityId = self.getIdFromIndex(self.activitiesIndexTranslation, i)
			labels.append(self.reversedActivities[activityId])
		
		return labels"""
