import math
import numpy
import random

import DataLoader as DL
import matplotlib.pyplot as plt
import pandas as pd

import seaborn as sns

from matplotlib import pyplot as plt

from sklearn import metrics
from sklearn.metrics import classification_report
from sklearn import preprocessing

from keras.callbacks import EarlyStopping
from keras.layers import Activation, Bidirectional, Dense, Flatten, LSTM
from keras.models import Sequential
from keras.utils import to_categorical

dl = DL.DataLoader("Activities.csv", "sensors.csv", "activities_data.csv")
data = dl.loadDataSeries()

x, y = [], []

for i in range(0, len(data)):
	x.append(int(data[i]['sensorId']))
	y.append(int(data[i]['timestamp']))

'''
a = numpy.bincount(x)
b = numpy.nonzero(a)[0]

total = 0
for i in a:
    total = total + i
    
t = 0
j = 0
for i in b:
    if((a[i]*100/total)>=0.7):
        j = j + 1
        print(i,a[i],a[i]*100/total)
        t = t + (a[i]*100/total)

print(t, j)
exit()
'''

points = x
data = pd.DataFrame({"a":points})

print(data.shape)

def loadData(data, _lookback = 10):
	X, Y = [], []

	for i in range(len(data) - _lookback):
		X.append(data.iloc[i:i+_lookback].values)
		Y.append(data.iloc[i+_lookback].values)

	dataX = numpy.array(X)
	dataY = numpy.array(Y)

	return dataX, dataY

def splitData(xData, yData, percentage):
	nValues = int(xData.shape[0]*percentage)
	
	xFirst = []
	yFirst = []
	xSecond = []
	ySecond = []
	
	for i in range(nValues):
		size = xData.shape[0]
		index = random.randint(0,size-1)
		xFirst.append(xData[index])
		yFirst.append(yData[index])
		xData = numpy.delete(xData, index, 0)
		yData = numpy.delete(yData, index, 0)
	
	xSecond = xData
	ySecond = yData
	
	xFirst = numpy.asarray(xFirst)
	xFirst = xFirst.astype('float32')
	yFirst = numpy.asarray(yFirst)
	yFirst = yFirst.astype('float32')
	
	xSecond = numpy.asarray(xSecond)
	xSecond = xSecond.astype('float32')
	ySecond = numpy.asarray(ySecond)
	ySecond = ySecond.astype('float32')
	
	return xFirst, yFirst, xSecond, ySecond

def plot_training_info(metrics, save, history):
    # summarize history for accuracy
    if 'accuracy' in metrics:
        
        plt.plot(history['accuracy'])
        plt.plot(history['val_accuracy'])
        plt.title('model accuracy')
        plt.ylabel('accuracy')
        plt.xlabel('epoch')
        plt.legend(['train', 'test'], loc='upper left')
        if save == True:
            plt.savefig('accuracy.png')
            plt.gcf().clear()
        else:
            plt.show()

    # summarize history for loss
    if 'loss' in metrics:
        plt.plot(history['loss'])
        plt.plot(history['val_loss'])
        plt.title('model loss')
        plt.ylabel('loss')
        plt.xlabel('epoch')
        #plt.ylim(1e-3, 1e-2)
        plt.yscale("log")
        plt.legend(['train', 'test'], loc='upper left')
        if save == True:
            plt.savefig('loss.png')
            plt.gcf().clear()
        else:
            plt.show()

historySize = 1
hiddenNeurons = 500
#maxNumber = points[-1] + 1
maxNumber = 147

dataX, dataY = loadData(data, historySize)
X, Y, testX, testY = splitData(dataX, dataY, 0.8)

finishCallback = EarlyStopping(monitor = 'val_loss', min_delta = 0.001, patience = 5)

model = Sequential()
#model.add(LSTM(hiddenNeurons, dropout=0.01, input_shape=(historySize,1), return_sequences=False))
#model.add(LSTM(hiddenNeurons, dropout=0.1, recurrent_dropout=0.5, input_shape=(historySize,maxNumber), return_sequences=True))
#model.add(LSTM(hiddenNeurons, dropout=0.1, recurrent_dropout=0.5, input_shape=(historySize,maxNumber), return_sequences=False))

#model.add(Bidirectional(LSTM(hiddenNeurons, unit_forget_bias=True, dropout=0.1, recurrent_dropout=0.5, return_sequences=True), merge_mode='concat', input_shape=(historySize, maxNumber,)))
#model.add(Bidirectional(LSTM(hiddenNeurons, unit_forget_bias=True, dropout=0.1, recurrent_dropout=0.5, return_sequences=True), merge_mode='concat', input_shape=(historySize, maxNumber,)))
model.add(Bidirectional(LSTM(hiddenNeurons, unit_forget_bias=True, dropout=0.1, recurrent_dropout=0.5, return_sequences=False, activation=None, recurrent_activation=None), merge_mode='concat', input_shape=(historySize, maxNumber,)))

#model.add(LSTM(hiddenNeurons, dropout=0.1, recurrent_dropout=0.5, input_shape=(historySize,maxNumber), return_sequences=True))
#model.add(LSTM(hiddenNeurons, dropout=0.1, recurrent_dropout=0.5, input_shape=(historySize,maxNumber), return_sequences=True))

#model.add(Bidirectional(LSTM(hiddenNeurons, unit_forget_bias=True, dropout=0.1, recurrent_dropout=0.5, return_sequences=False), merge_mode='concat', input_shape=(historySize, maxNumber,)))
#model.add(Bidirectional(LSTM(2*hiddenNeurons, dropout=0.01, return_sequences=True), merge_mode='concat'))
#model.add(Flatten())
#model.add(Dense(100))

model.add(Dense(maxNumber))
model.compile(loss="mean_squared_error", optimizer="rmsprop", metrics=['accuracy', 'mse', 'mae'])

#model.fit(X, Y, batch_size=1, epochs=1000, validation_split=0.2, callbacks = [finishCallback])
history = model.fit(to_categorical(X, maxNumber), to_categorical(Y, maxNumber), batch_size=30, epochs=100, validation_split=0.2, callbacks = [finishCallback])

predicted = model.predict(to_categorical(testX, maxNumber))
rmse = numpy.sqrt(((numpy.argmax(predicted) - testY) ** 2).mean(axis=0))

#print(rmse)

predictedY = []

realUsed = numpy.zeros(148)
predictedUsed = numpy.zeros(148)

correct = 0
for i in range(0, len(predicted)):
	predictedUsed[numpy.argmax(predicted[i])] = 1
	realUsed[int(testY[i])] = 1
	
	predictedY.append(numpy.argmax(predicted[i]))
	
	if numpy.argmax(predicted[i]) == testY[i]:
		correct = correct + 1

#print(numpy.argmax(predicted[i]), testY[i])

print(correct/len(predicted))

labels = []
for i in range(51, 147):
	print(realUsed[i], predictedUsed[i], realUsed[i] > 0, predictedUsed[i] > 0)
	if realUsed[i] > 0 or predictedUsed[i] > 0:
		labels.append(i)

nLabels = []
for i in range(len(labels)):
	nLabels.append(i)

print(realUsed, predictedUsed)
print(labels, nLabels)

matrix = metrics.confusion_matrix(testY, predictedY, labels=nLabels)
plt.figure(figsize=(20, 15))
sns.heatmap(matrix, cmap='coolwarm', linecolor='white', linewidths=1, xticklabels=labels, yticklabels=labels, annot=True, fmt='d')
plt.title('Confusion Matrix')
plt.ylabel('True Label')
plt.xlabel('Predicted Label')
plt.show()

print(history.history)
plot_training_info(['accuracy', 'loss'], False, history.history)

#plt.plot(predicted, 'r', testY, 'b')
#plt.show()
