import copy
import csv
import numpy

import random


class DataLoader:
    def __init__(self, activitiesFile, sensorsFile, activitiesDataFile):
        self.activitiesFile = activitiesFile
        self.sensorsFile = sensorsFile
        self.activitiesDataFile = activitiesDataFile

        self.activities = {}
        self.reversedActivites = {}
        self.sensors = {}
        self.reversedSensors = {}
        self.dataSeries = []
                
        self.activitiesSize = 0
        self.sensorsSize = 0
    
    def convertListOfStringsToListOfFloats(self, listOfValues):
        return list(
                    map(
                        lambda value: float(value), list( listOfValues.strip('[]').split(',') )
                    )
                )
    
    def loadActivities(self):        
        print("Loading activities")
        with open(self.activitiesFile, 'r') as inputFile:
            reader = csv.reader(inputFile)
            lineNumber = 1
            
            try:
                for row in reader:
                    lineNumber += 1
                    
                    self.activitiesSize += 1
                    
                    activityId = row[0]
                    activityLabel = row[1]
                    
                    self.activities[activityLabel] = activityId
                    self.reversedActivites[activityId] = activityLabel
                    
            except Exception as exception:
                print (("Error line %d: %s %s" % (lineNumber, str(type(exception)), exception)))

        return self.activities, self.reversedActivities, self.activitiesSize
	
    def loadSensors(self):
        print("Loading sensors")
        with open(self.sensorsFile, 'r') as inputFile:
            reader = csv.reader(inputFile)
            lineNumber = 1
            
            try:
                for row in reader:
                    lineNumber += 1
                    
                    self.sensorsSize += 1
                    
                    sensorId = row[0]
                    sensorLabel = row[1]
                    
                    self.sensors[sensorLabel] = sensorId
                    self.reversedSensors[sensorId] = sensorLabel
                    
            except Exception as exception:
                print (("Error line %d: %s %s" % (lineNumber, str(type(exception)), exception)))
        
        return self.sensors, self.reversedSensors, self.sensorsSize

    def loadDataSeries(self):
        print("Loading events data")
        with open(self.activitiesDataFile, 'r') as inputFile:
            reader = csv.reader(inputFile, delimiter=',', quotechar="'")
            lineNumber = 1
            
            try:
                for row in reader:
                    lineNumber += 1
                    
                    sineTimestamp = float(row[0])
                    cosineTimestamp = float(row[1])
                    itemValues = self.convertListOfStringsToListOfFloats(row[2])
                    activities = self.convertListOfStringsToListOfFloats(row[3])
                    
                    self.dataSeries.append([sineTimestamp, cosineTimestamp, itemValues, activities])
                    
            except Exception as exception:
                print (("Error line %d: %s %s" % (lineNumber, str(type(exception)), exception)))
        
        return self.dataSeries
    
    def simplifyOutput(self, data):
        print("Simplifying output data")
        
        simplifiedData = copy.deepcopy(data)
        rows, columns = simplifiedData.shape
        for row in range(rows):
            outputActivities = simplifiedData[row, 3]
            
            simplifiedOutput = [0, 0]
            if outputActivities[0] > 0:
                simplifiedOutput[0] = 1
            else:
                simplifiedOutput[1] = 1
                
            simplifiedData[row, 3] = simplifiedOutput
        
        return simplifiedData
