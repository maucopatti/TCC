import argparse
import math
import numpy
import random

import DataLoader as DL
import pandas as pd

from keras.callbacks import EarlyStopping
from keras.layers import Activation, Bidirectional, Dense, Flatten, LSTM
from keras.models import Sequential
from keras.optimizers import Adam
from tensorflow import keras

# Command line arguments
parser = argparse.ArgumentParser()

# Flag options #
parser.add_argument('--train', dest='train', default=False, action='store_true', help='set train mode')
parser.add_argument('--predict', dest='predict', default=False, action='store_true', help='set predict mode')
parser.add_argument('--verbose', dest='verbose', default=False, action='store_true', help='set verbose mode')

# Data input options #
parser.add_argument('--activities-file', dest='activitiesFile', default='labelActivities.csv', help='define file containing activities names and IDs')
parser.add_argument('--sensors-file', dest='sensorsFile', default='lavelItems.csv', help='define file containing sensor names and IDs')
parser.add_argument('--data-file', dest='dataFile', default='allDataRoom4.csv', help='define file containing sensor data for activities')
parser.add_argument('--model-file', dest='modelFile', default='model', help='define file containing the network model and state')

# Training options #
parser.add_argument('--timesteps', dest='timestepsSize', type=int, default=1, help='set number of steps back in time to be considered')
parser.add_argument('--units', dest='numberOfUnits', type=int, default=10, help='set number of units on LSTM layer')
parser.add_argument('--unidirectional-lstm', dest='unidirectionalLstm', default=False, action='store_true', help='use unidirectional LSTM instead of the default, which is bidirectional')
parser.add_argument('--batch-size', dest='batchSize', type=int, default=1, help='set number of samples by batch')
parser.add_argument('--epochs', dest='epochs', type=int, default=100, help='set number of epochs of training')
parser.add_argument('--no-early-stop', dest='noEarlyStop', default=False, action='store_true', help='set network not to use early stop. Early stop preventing overfitting')


args = parser.parse_args()


''' Auxiliary Functions '''

def loadData(data, _lookback = 10, drop = True):
        dataX, dataY = [], []
        
        i = 0
        for row in data:
            if drop:
                # dropping some 'None' activities
                if row[3][0] == 1: # if is 'None'
                    #if random.random() < 0.1: # drop aprox. 90% of 'None'
                    if random.random() < 0.25: # drop aprox. 75% of 'None'
                        dataX.append([row[0], row[1]])
                        dataX[i].extend(row[2])
                        
                        i += 1
                        
                        dataY.append(row[3])
                else: # use all non-'None' activities
                    dataX.append([row[0], row[1]])
                    dataX[i].extend(row[2])
                    
                    i += 1
                    
                    dataY.append(row[3])
            else:
                dataX.append([row[0], row[1]])
                dataX[i].extend(row[2])
                
                i += 1
                
                dataY.append(row[3])

        dataX = numpy.asarray(dataX)
        dataY = numpy.asarray(dataY)
    
        x, y = [], []

        for i in range(len(dataX) - _lookback):
            x.append(dataX[i:i+_lookback])
            y.append(dataY[i+_lookback])

        x = numpy.array(x)
        y = numpy.array(y)

        return x, y

def splitData(xData, yData, percentage):
    nValues = int(xData.shape[0]*percentage)
    
    concatenatedData = []
    for i in range(len(xData)):
        concatenatedData.append([xData[i],yData[i]])
        
    random.shuffle(concatenatedData)
    
    X = []
    Y = []
    for i in range(len(concatenatedData)):
        X.append(concatenatedData[i][0])
        Y.append(concatenatedData[i][1])

    xFirst = X[0:nValues]
    yFirst = Y[0:nValues]
    xSecond = X[nValues:]
    ySecond = Y[nValues:]

    xFirst = numpy.asarray(xFirst)
    #xFirst = xFirst.astype('float32')
    yFirst = numpy.asarray(yFirst)
    #yFirst = yFirst.astype('float32')

    xSecond = numpy.asarray(xSecond)
    #xSecond = xSecond.astype('float32')
    ySecond = numpy.asarray(ySecond)
    #ySecond = ySecond.astype('float32')

    return xFirst, yFirst, xSecond, ySecond

''' End of Auxiliary Functions '''


if(args.train):
    # Train the network
    
    dl = DL.DataLoader(args.activitiesFile, args.sensorsFile, args.dataFile)
    data = dl.loadDataSeries()
                
    data = numpy.asarray(data)
    
    simplifiedData = dl.simplifyOutput(data)
        
    totalSize = simplifiedData.shape[0]
    withActivitySize = len(list(filter(lambda x : x[3][1] > 0, simplifiedData)))
    withoutActivitySize = totalSize - withActivitySize
    
    if (args.verbose):
        print("There are " + str(withActivitySize) + " records with activity out of " + str(totalSize) + " (" + str(100*withActivitySize/totalSize) + "%)")
        print("There are " + str(withoutActivitySize) + " records without activity out of " + str(totalSize) + " (" + str(100*withoutActivitySize/totalSize) + "%)")
    
    ### First Network ###
    
    timestepsSize = args.timestepsSize
    optimizer = Adam(
        learning_rate=0.001,
        beta_1=0.9,
        beta_2=0.999,
        epsilon=1e-07
    )
    
    dataX, dataY = loadData(simplifiedData, timestepsSize)
    
    numberInputVariables = dataX.shape[2]
    numberOutputCategories = dataY.shape[1]
    
    total = dataX.shape[0]
    trainPercentage = 1
    trainSize = int(total*trainPercentage)

    X = numpy.asarray(dataX[0:trainSize])
    Y = numpy.asarray(dataY[0:trainSize])
    
    if(args.verbose):
        print('Train input shape: ' + str(X.shape))
        print('Train output shape: ' + str(Y.shape))
    
    testX = numpy.asarray(dataX[trainSize:])
    testY = numpy.asarray(dataY[trainSize:])
    
    if(args.verbose):
        print('Test input shape: ' + str(testX.shape))
        print('Test output shape: ' + str(testY.shape))
    
    finishCallback = EarlyStopping(monitor = 'val_categorical_accuracy', min_delta = 0.001, patience = 15)

    firstLayerModel = Sequential()
    
    if (args.unidirectionalLstm):
        firstLayerModel.add(LSTM(args.numberOfUnits, unit_forget_bias=True, dropout=0.01, recurrent_dropout=0.5, return_sequences=False, activation='relu', recurrent_activation='tanh'))
    else:
        firstLayerModel.add(Bidirectional(LSTM(args.numberOfUnits, unit_forget_bias=True, dropout=0.01, recurrent_dropout=0.5, return_sequences=False, activation='relu', recurrent_activation='tanh'), merge_mode='concat', input_shape=(timestepsSize,numberInputVariables,)))

    firstLayerModel.add(Dense(numberOutputCategories, activation='softmax'))
    
    firstLayerModel.compile(loss="categorical_crossentropy", optimizer=optimizer, metrics=['categorical_accuracy', 'categorical_crossentropy'])

    if (args.verbose):
        print(firstLayerModel.summary())

    if(args.noEarlyStop):
        firstLayerHistory = firstLayerModel.fit(X, Y, validation_split = 0.2, batch_size=args.batchSize, epochs=args.epochs)
    else:
        firstLayerHistory = firstLayerModel.fit(X, Y, validation_split = 0.2, batch_size=args.batchSize, epochs=args.epochs, callbacks = [finishCallback])

    firstLayerModel.save(str(args.modelFile) + "_L1")

    ### Second Network ###
    
    timestepsSize = args.timestepsSize
    optimizer = Adam(
        learning_rate=0.001,
        beta_1=0.9,
        beta_2=0.999,
        epsilon=1e-07
    )
    
    dataX, dataY = loadData(data, timestepsSize, False)
    
    # Filter data
    filteredDataX = []
    filteredDataY = []
    
    activityPredictions = list(filter(lambda x : numpy.argmax(x[1]) > 0, enumerate(dataY))) # Get index only for 'Activity' predictions
    for activity in activityPredictions:
        filteredDataX.append(dataX[activity[0]])
        filteredDataY.append(dataY[activity[0]])
    
    filteredDataX = numpy.asarray(filteredDataX)
    filteredDataY = numpy.asarray(filteredDataY)
    
    numberInputVariables = filteredDataX.shape[2]
    numberOutputCategories = filteredDataY.shape[1]

    total = filteredDataX.shape[0]
    trainPercentage = 1
    trainSize = int(total*trainPercentage)

    X = numpy.asarray(filteredDataX[0:trainSize])
    Y = numpy.asarray(filteredDataY[0:trainSize])
    if(args.verbose):
        print('Train input shape: ' + str(X.shape))
        print('Train output shape: ' + str(Y.shape))
    
    testX = numpy.asarray(filteredDataX[trainSize:])
    testY = numpy.asarray(filteredDataY[trainSize:])
    if(args.verbose):
        print('Test input shape: ' + str(testX.shape))
        print('Test output shape: ' + str(testY.shape))

    finishCallback = EarlyStopping(monitor = 'val_categorical_accuracy', min_delta = 0.001, patience = 15)

    secondLayerModel = Sequential()
    
    if (args.unidirectionalLstm):
        secondLayerModel.add(LSTM(args.numberOfUnits, unit_forget_bias=True, dropout=0.1, recurrent_dropout=0.1, return_sequences=False, activation='tanh', recurrent_activation='relu'))
    else:
        secondLayerModel.add(Bidirectional(LSTM(args.numberOfUnits, unit_forget_bias=True, dropout=0.1, recurrent_dropout=0.1, return_sequences=False, activation='tanh', recurrent_activation='relu'), merge_mode='concat', input_shape=(timestepsSize,numberInputVariables,)))

    secondLayerModel.add(Dense(numberOutputCategories, activation='softmax'))
    
    secondLayerModel.compile(loss="categorical_crossentropy", optimizer=optimizer, metrics=['categorical_accuracy', 'categorical_crossentropy'])

    if (args.verbose):
        print(secondLayerModel.summary())

    if (args.noEarlyStop):
        secondLayerHistory = secondLayerModel.fit(X, Y, validation_split = 0.2, batch_size=args.batchSize, epochs=args.epochs)
    else:
        secondLayerHistory = secondLayerModel.fit(X, Y, validation_split = 0.2, batch_size=args.batchSize, epochs=args.epochs, callbacks = [finishCallback])
    
    secondLayerModel.save(str(args.modelFile) + "_L2")

if (args.predict):
    firstLayerModel = keras.models.load_model(str(args.modelFile) + "_L1")
    secondLayerModel = keras.models.load_model(str(args.modelFile) + "_L2")

    dl = DL.DataLoader(args.activitiesFile, args.sensorsFile, args.dataFile)
    data = dl.loadDataSeries()

    data = numpy.asarray(data)

    dataX, dataY = loadData(data, args.timestepsSize, False)

    firstLayerPrediction = firstLayerModel.predict(dataX)

    nonActivityDataX = []
    nonActivityDataY = []
    activityDataX = []
    activityDataY = []

    nonActivityPredictions = list(filter(lambda x : numpy.argmax(x[1]) == 0, enumerate(firstLayerPrediction))) # Get index only for 'Non-Activity' predictions
    activityPredictions = list(filter(lambda x : numpy.argmax(x[1]) > 0, enumerate(firstLayerPrediction))) # Get index only for 'Activity' predictions

    for activity in nonActivityPredictions:
        nonActivityDataX.append(dataX[activity[0]])
        nonActivityDataY.append(dataY[activity[0]])

    for activity in activityPredictions:
        activityDataX.append(dataX[activity[0]])
        activityDataY.append(dataY[activity[0]])

    nonActivityDataX = numpy.asarray(nonActivityDataX)
    nonActivityDataY = numpy.asarray(nonActivityDataY)
    activityDataX = numpy.asarray(activityDataX)
    activityDataY = numpy.asarray(activityDataY)

    secondLayerPrediction = secondLayerModel.predict(activityDataX)

    correct = 0
    total = 0

    for i in range(0, len(nonActivityPredictions)):
        total = total + 1
        if numpy.argmax(nonActivityPredictions[i][1]) == numpy.argmax(nonActivityDataY[i]):
            correct = correct + 1

    for i in range(0, len(secondLayerPrediction)):
        total = total + 1
        if numpy.argmax(secondLayerPrediction[i]) == numpy.argmax(activityDataY[i]):
            correct = correct + 1

    print(100*correct/total)
